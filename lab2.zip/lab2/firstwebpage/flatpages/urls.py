from django.contrib import admin
from django.urls import path
from flatpages import views


urlpatterns = [
    path('', views.index, name='index2'),
    path('hello/', views.index_no_type, name='index2')
]